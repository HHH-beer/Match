import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import serial

class SprayNode(Node):
    def __init__(self):
        super().__init__("spray_node")
        self.sub = self.create_subscription(String, "/relay_cmd", self.callback, 10)
        self.get_logger().info("✅ 继电器控制节点已启动")

        try:
            self.ser = serial.Serial("/dev/ttyACM0", 115200, timeout=0.5)
            self.get_logger().info("🔌 串口连接成功")
        except:
            self.get_logger().error("❌ 串口连接失败")
            self.ser = None

    def callback(self, msg):
        cmd = msg.data
        self.get_logger().info(f"📥 收到指令：{cmd}")
        if self.ser:
            self.ser.write((cmd + "\n").encode())

def main(args=None):
    rclpy.init(args=args)
    node = SprayNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()