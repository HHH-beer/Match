import rclpy
from rclpy.node import Node
import serial
import curses

class KeyRelayNode(Node):
    def __init__(self):
        super().__init__("key_relay_node")
        self.get_logger().info("✅ 键盘继电器节点已启动")

        # 连接 Arduino 串口
        try:
            self.ser = serial.Serial("/dev/ttyACM0", 115200, timeout=0.5)
            self.get_logger().info("🔌 串口连接成功")
        except:
            self.get_logger().error("❌ 串口连接失败")
            self.ser = None

    def open_relay(self):
        if self.ser:
            self.ser.write(b"OPEN\n")
            self.get_logger().info("💨 继电器 OPEN")

    def close_relay(self):
        if self.ser:
            self.ser.write(b"CLOSE\n")
            self.get_logger().info("🛑 继电器 CLOSE")

# --------------------- 主函数修复版 ---------------------
def main():
    def run(stdscr):
        rclpy.init()
        node = KeyRelayNode()

        curses.noecho()
        curses.cbreak()
        stdscr.nodelay(True)

        while rclpy.ok():
            key = stdscr.getch()

            if key == curses.KEY_UP:
                node.open_relay()
            elif key == curses.KEY_DOWN:
                node.close_relay()
            elif key == ord('q'):
                break

            rclpy.spin_once(node, timeout_sec=0.01)

        node.destroy_node()
        rclpy.shutdown()

    curses.wrapper(run)

if __name__ == "__main__":
    main()