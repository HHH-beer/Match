import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import curses

class SpraySend(Node):
    def __init__(self):
        super().__init__("spray_sent_node")
        self.pub = self.create_publisher(String, "/relay_cmd", 10)
        self.get_logger().info("✅ 键盘发布节点已启动：↑开 ↓关 q退出")

    def pub_open(self):
        msg = String()
        msg.data = "OPEN"
        self.pub.publish(msg)
        self.get_logger().info("📤 发送 OPEN")

    def pub_close(self):
        msg = String()
        msg.data = "CLOSE"
        self.pub.publish(msg)
        self.get_logger().info("📤 发送 CLOSE")

def run_node(stdscr):
    rclpy.init()
    node = SpraySend()

    curses.noecho()
    curses.cbreak()
    stdscr.nodelay(True)

    while rclpy.ok():
        key = stdscr.getch()

        if key == curses.KEY_UP:
            node.pub_open()
        elif key == curses.KEY_DOWN:
            node.pub_close()
        elif key == ord('q'):
            break

        rclpy.spin_once(node, timeout_sec=0.05)

    node.destroy_node()
    rclpy.shutdown()

# 这是修复报错的关键！！！
def main():
    curses.wrapper(run_node)

if __name__ == "__main__":
    main()