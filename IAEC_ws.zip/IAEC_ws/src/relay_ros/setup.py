import glob
import os
from setuptools import find_packages, setup

package_name = 'relay_ros'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),

               # 正确的 launch 文件安装路径
        (os.path.join('share', package_name, 'launch'), glob.glob('launch/*.launch.py')),


    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='iris',
    maintainer_email='iris@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'spray_node= relay_ros.spray_node:main',
            'spray_sent= relay_ros.spray_sent:main',
            'keyboard_node= relay_ros.keyboard_node:main',
        ],
    },
)
