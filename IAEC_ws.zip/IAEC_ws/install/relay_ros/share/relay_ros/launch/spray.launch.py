from launch import LaunchDescription
from launch.actions import TimerAction
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. 先启动：继电器订阅节点
        Node(
            package="relay_ros",
            executable="spray_node",
            name="spray_node",
            output="screen",
        ),

        # 2. 延迟 0.5 秒 → 再启动键盘发送节点
        TimerAction(
            period=0.5,
            actions=[
                Node(
                    package="relay_ros",
                    executable="spray_sent",
                    name="spray_sent_node",
                    output="screen",
                )
            ]
        ),
    ])